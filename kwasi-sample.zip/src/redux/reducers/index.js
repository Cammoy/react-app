import {combineReducers} from 'redux';

import bikes from './bikes';

export default combineReducers({
  bikes,
});
